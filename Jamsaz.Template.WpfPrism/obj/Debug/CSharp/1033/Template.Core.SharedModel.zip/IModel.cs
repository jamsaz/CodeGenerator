﻿namespace $safeprojectname$
{
    public interface IModel 
    {
    }
}