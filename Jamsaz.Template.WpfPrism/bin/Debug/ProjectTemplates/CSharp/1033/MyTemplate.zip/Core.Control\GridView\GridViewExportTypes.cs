﻿namespace $safeprojectname$.GridView
{
    public enum GridViewExportTypes
    {
        Pdf = 0,
        Excel = 1
    }
}
