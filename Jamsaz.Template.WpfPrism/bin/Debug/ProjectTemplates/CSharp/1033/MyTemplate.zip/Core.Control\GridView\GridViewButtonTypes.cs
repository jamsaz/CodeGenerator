﻿namespace $safeprojectname$.GridView
{
    public enum GridViewButtonTypes
    {
        ExportGridViewButton = 0,
        AddNewRecordButton = 1,
        EditRecordButton = 2,
        DeleteRecordButton = 3,
        PrintGridViewButton = 4
    }
}
