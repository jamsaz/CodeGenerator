﻿using Telerik.Windows.Controls;

namespace $safeprojectname$.FormFields.ListView
{
    public class ListView : RadListBox
    {
        public ListView()
        {

        }
    }
}
