﻿using System.Collections.ObjectModel;
namespace $safeprojectname$.GridView
{
    public class GridViewButtonCollection : ObservableCollection<GridViewButton>
    {
    }
}
