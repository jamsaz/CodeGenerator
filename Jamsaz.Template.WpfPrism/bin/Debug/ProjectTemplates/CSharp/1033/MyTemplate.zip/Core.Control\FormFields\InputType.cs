﻿namespace $safeprojectname$.FormFields
{
    public enum InputType
    {
        Text = 0,
        Number = 1,
        Email = 2,
        NationalCode = 3,
        Desciption = 4
    }
}
