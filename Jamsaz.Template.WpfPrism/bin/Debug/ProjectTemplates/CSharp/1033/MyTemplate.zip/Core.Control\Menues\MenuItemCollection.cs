﻿using System.Collections.ObjectModel;

namespace $safeprojectname$.Menues
{
    public class MenuItemCollection : ObservableCollection<MenuItem>
    {
    }
}
