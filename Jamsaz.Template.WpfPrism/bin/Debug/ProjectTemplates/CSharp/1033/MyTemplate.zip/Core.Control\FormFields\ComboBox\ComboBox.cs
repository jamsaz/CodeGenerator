﻿using Telerik.Windows.Controls;

namespace $safeprojectname$.FormFields.ComboBox
{
    public class ComboBox : RadComboBox
    {

    }
}
