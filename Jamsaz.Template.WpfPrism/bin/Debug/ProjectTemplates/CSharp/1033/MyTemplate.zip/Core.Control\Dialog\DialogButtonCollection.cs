﻿using System.Collections.ObjectModel;
using $safeprojectname$.FormFields;

namespace $safeprojectname$.Dialog
{
    public class DialogButtonCollection : ObservableCollection<DialogButton>
    {

    }
}
