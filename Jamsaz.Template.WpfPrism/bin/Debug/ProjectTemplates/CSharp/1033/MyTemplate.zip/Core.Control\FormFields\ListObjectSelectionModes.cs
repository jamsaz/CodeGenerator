﻿namespace $safeprojectname$.FormFields
{
    public enum ListObjectSelectionModes
    {
        Multiple = 2,
        Single = 3
    }
}
