﻿namespace $safeprojectname$.GridView
{
    public enum GridViewColumnTypes
    {
        DataColumn = 0,
        CheckBoxColumn = 1,
        ComboBoxColumn = 2,
        TextBoxColumn = 3
    }
}
