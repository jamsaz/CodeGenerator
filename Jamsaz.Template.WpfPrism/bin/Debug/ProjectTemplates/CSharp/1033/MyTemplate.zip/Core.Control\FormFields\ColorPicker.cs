﻿using Telerik.Windows.Controls;

namespace $safeprojectname$.FormFields
{
    public class ColorPicker : RadColorPicker
    {

    }
}
