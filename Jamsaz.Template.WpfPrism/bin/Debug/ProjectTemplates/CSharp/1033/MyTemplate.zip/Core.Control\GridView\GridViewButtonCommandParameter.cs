﻿namespace $safeprojectname$.GridView
{
    public class GridViewButtonCommandParameter
    {
        public object Parent { get; set; }
        public GridViewButtonTypes Action { get; set; }
        public object Parameter { get; set; }
    }
}
