﻿namespace $safeprojectname$.FormFields.SelectForm
{
    public class SelectFormField
    {
        public SelectFormFieldTypes FieldTypes { get; set; }
        //If FieldTypes is Form Field Must Be Specific
        public FieldTypes Field { get; set; }
    }
}
