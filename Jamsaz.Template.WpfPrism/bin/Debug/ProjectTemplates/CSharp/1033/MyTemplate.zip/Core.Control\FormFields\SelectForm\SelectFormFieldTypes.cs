﻿namespace $safeprojectname$.FormFields.SelectForm
{
    public enum SelectFormFieldTypes
    {
        ComboBox = 0,
        Form = 1
    }
}
